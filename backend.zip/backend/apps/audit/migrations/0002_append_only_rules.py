# Generated migration for append-only audit rules
from django.db import migrations


class Migration(migrations.Migration):
    """
    Add DB-level rules to enforce append-only behavior on the AuditEvent table.

    These PostgreSQL rules prevent UPDATE and DELETE operations on the
    audit_auditevent table, ensuring the audit trail is truly immutable
    at the database level.
    """

    dependencies = [
        ('audit', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(
            sql=[
                "CREATE OR REPLACE RULE no_update_audit AS ON UPDATE TO audit_auditevent DO INSTEAD NOTHING;",
                "CREATE OR REPLACE RULE no_delete_audit AS ON DELETE TO audit_auditevent DO INSTEAD NOTHING;",
            ],
            reverse_sql=[
                "DROP RULE IF EXISTS no_update_audit ON audit_auditevent;",
                "DROP RULE IF EXISTS no_delete_audit ON audit_auditevent;",
            ],
        ),
    ]
